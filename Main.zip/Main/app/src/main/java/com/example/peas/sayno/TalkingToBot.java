package com.example.peas.sayno;

import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.Arrays;

/**
 * Created by Tanush on 2017-04-01.
 */

public class TalkingToBot extends AppCompatActivity {
    ArrayList<String> lis = new ArrayList<String>();
    /*public void onButtonClick(View v){
        Button AI = (Button) findViewById(R.id.button3);
        String message = msg.getText().toString();
        int len = message.length();

        String newStr = message.toLowerCase();
        lis = new ArrayList<String>(Arrays.asList(message.split(" ")));
    }*/

}
