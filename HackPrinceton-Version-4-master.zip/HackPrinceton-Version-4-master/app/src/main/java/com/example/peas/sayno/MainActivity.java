package com.example.peas.sayno;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public String onButtonClick(View v){
        EditText msg = (EditText) findViewById(R.id.editText3);
        TextView t1 = (TextView) findViewById(R.id.lol123);
        String message = msg.getText().toString();
        return message;
    }


}
