package com.example.peas.sayno;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by jarron on 4/1/17.
 */

public class user {

    public static ArrayList<String> userSendMsg(String str){
        int len = str.length();

        String newStr = str.toLowerCase();
        ArrayList<String> lis = new ArrayList<String>(Arrays.asList(str.split(" ")));

        return lis;
    }
}
