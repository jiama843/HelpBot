package com.example.peas.sayno;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by jarron on 4/1/17.
 */

public class Bot {
   public  List<String> keys = new ArrayList<String>();
   public  List<String> listOfTheKeys = new ArrayList<String>();
   public  String reply;



    public void init() {
        keys.add("i");
        keys.add("hi");
        keys.add("me");
        keys.add("he");
        keys.add("she");
        keys.add("they");
        keys.add("hate");
        keys.add("harass");
        keys.add("harassment");
        keys.add("bully");
        keys.add("how");
        keys.add("are");
        keys.add("you");
        keys.add("rape");
        keys.add("raped");
        keys.add("sexuality");
        keys.add("sex");
        keys.add("force");
        keys.add("have");
        keys.add("gay");
        keys.add("bi");
        keys.add("bisexual");
        keys.add("les");
        keys.add("lez");
        keys.add("lesbian");
        keys.add("lesbians");
        keys.add("fag");
        keys.add("faggot");
        keys.add("help");
        keys.add("police");
        keys.add("domestic");
        keys.add("violence");
        keys.add("violent");
        keys.add("ugly");
        keys.add("am");
        keys.add("doing");
        keys.add("need");
    }

    public void handleUserInput(List<String> personString ) {
        for (int i = 0; i < personString.size(); i++) {
            if(keys.contains(personString.get(i))) {
                listOfTheKeys.add(personString.get(i));
            }
        }
    }

    public String respond() {
        if(listOfTheKeys.contains("i") && listOfTheKeys.contains("hate")){
            reply = "Hating is bad for your health, spread positivity";
        } else if(listOfTheKeys.contains("ugly") && listOfTheKeys.contains("i") &&
                listOfTheKeys.contains("am")){
            reply = "Everyone is beautiful";
        } else if((listOfTheKeys.contains("i") && listOfTheKeys.contains("am")) &&
                (listOfTheKeys.contains("gay") || listOfTheKeys.contains("les")
                        || listOfTheKeys.contains("lesbian"))) {
            reply = "You can be any sexual orientation you wish";
        }else if(listOfTheKeys.contains("hi")) {
            reply = "Hi there";

        }else if(listOfTheKeys.contains("hi") && listOfTheKeys.contains("how") &&
                listOfTheKeys.contains("are") && listOfTheKeys.contains("you")) {
            reply = "Im good thanks for asking";
        }else if(listOfTheKeys.contains("how") &&
                listOfTheKeys.contains("are") && listOfTheKeys.contains("you")) {
            reply = "Im good thanks for asking";
        }else if(listOfTheKeys.contains("how") &&
                listOfTheKeys.contains("you") && listOfTheKeys.contains("doing")) {
            reply = "Im good thanks for asking";
        }else if((listOfTheKeys.contains("i") &&
                listOfTheKeys.contains("need")) &&
                (listOfTheKeys.contains("help") || listOfTheKeys.contains("advice"))) {
            reply = "How can I help you?";
        }else {
            reply = "Please revise your message as I am to primitive to understand :)";
        }


            return reply;
    }

}
