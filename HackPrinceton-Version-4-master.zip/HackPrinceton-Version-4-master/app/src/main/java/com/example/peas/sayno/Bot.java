package com.example.peas.sayno;

/**
 * Created by jarron on 4/1/17.
 */

public class Bot {
    String [] keyWords;

}
